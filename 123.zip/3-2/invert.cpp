#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

const int N = 3;

struct matrix {
    double matrix[3][3];
};

double power(double base, int exponent)
{
    double result = 1;
    for (int i = 0; i < exponent; i++)
        result *= base;
    return result;
}

double FindDet2(const double a[N-1][N-1])
{
    return a[0][0] * a[1][1] - a[0][1] * a[1][0];
}

double FindDet3(matrix a)
{
    return a.matrix[0][0] * (a.matrix[1][1] * a.matrix[2][2] - a.matrix[2][1] * a.matrix[1][2]) -
           a.matrix[0][1] * (a.matrix[1][0] * a.matrix[2][2] - a.matrix[2][0] * a.matrix[1][2]) +
           a.matrix[0][2] * (a.matrix[1][0] * a.matrix[2][1] - a.matrix[2][0] * a.matrix[1][1]);
}

void TakeMinor(const matrix a, double (&minor)[N-1][N-1], int i, int j)
{
    for (int majorX = 0, minorX = 0; majorX < N; ++majorX)
    {
        if (majorX == i) continue;
        for (int majorY = 0, minorY = 0; majorY < N; ++majorY)
        {
            if (majorY == j) continue;
            minor[minorX][minorY] = a.matrix[majorX][majorY];
            ++minorY;
        }
        ++minorX;
    }
}

bool InvertMatrix(const matrix matrix, struct matrix& invertedMatrix)
{
    double det = FindDet3(matrix);
    if (det == 0)
        return false;

    double minor[N-1][N-1];
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
        {
            TakeMinor(matrix, reinterpret_cast<double (&)[N-1][N-1]>(minor), i, j);
            invertedMatrix.matrix[j][i] = power(-1, i + j) * FindDet2(minor) / det;
            if (std::signbit(invertedMatrix.matrix[j][i]) && invertedMatrix.matrix[j][i] == 0.0)   //Avoiding negative zero
                invertedMatrix.matrix[j][i] = 0.0;                                                    //
        }
    return true;
}

bool ReadMatrix(const string& inputFileName, struct matrix& a)
{
    ifstream input(inputFileName);
    if (!input.is_open())
    {
        cout << "Unable to open input file" << endl;
        return false;
    }

    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
        {
            if (input.eof())
                return false;
            input >> a.matrix[i][j];
        }
    return true;
}

bool ReverseMatrixCalculation(int argc, const string& inputFileName, struct matrix& invertedMatrix)
{
    if (argc != 2)
    {
        cout << "Usage: invert.exe <matrix file1>" << endl;
        return false;
    }

    matrix matrix{};
    if (!ReadMatrix(inputFileName, matrix))
    {
        cout << "Invalid data format in input file" << endl;
        return false;
    }

    if (!InvertMatrix(matrix, invertedMatrix))
    {
        cout << "No inverse exists" << endl;
        return false;
    }

    cout << fixed << setprecision(3);
    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
            cout << invertedMatrix.matrix[i][j] << " ";
        cout << endl;
    }

    return true;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        cout << "Usage: invert.exe <matrix file1>" << endl;
        return 1;
    }
    matrix invertedMatrix{};

    return !ReverseMatrixCalculation(argc, argv[1], invertedMatrix);
}


