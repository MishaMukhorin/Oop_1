#include <iostream>
#include <string>
#include <limits>
#include <algorithm>

using namespace std;

string ReverseString(string str)
{
    std::reverse(str.begin(), str.end());
    return str;
}

int CharToInt(const char c, bool& wasError)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    else if (c >= 'A' && c <= 'Z')
        return c - 'A' + 10;
    else
        wasError = true;
    return 0;
}

char IntToChar(const int digit)
{
    if (digit < 10)
        return digit + '0';
    else
        return digit + 'A' - 10;
}

int StringToInt(const string& str, int radix, bool& wasError)
{
    wasError = false;
    int result = 0;
    int sign = 1;
    for (char c : str)
    {
        if (c == '-')
        {
            sign = -1;
            continue;
        }
        int digit = CharToInt(c, wasError);
        if (digit >= radix) {
            wasError = true;
            break;
        }
        if (result > (numeric_limits<int>::max() - digit) / radix)
        {
            wasError = true;
            break;
        }
        result = result * radix + digit;
    }
    if (wasError)
        return 0;
    return result * sign;
}

string IntToString(int n, int radix, bool& wasError)
{
    if (n == 0)
        return "0";
    string result;
    bool isNegative = n < 0;
    if (n == std::numeric_limits<int>::min())
        wasError = true;
    n = abs(n);                                               //done корректно обрабатывать значение intmin
    while (n > 0)
    {
        int digit = n % radix;                                   //done IntToChar
        result += IntToChar(digit);
        n /= radix;
    }                                                            //done вставка в конец с инверсией
    if (isNegative)
        result += '-';
    return ReverseString(result);
}

bool ParseArgs(char* argv[], const int& argc, string& sourceRadix, string& destinationRadix, string& inputValue)
{
    if (argc != 4)
        return false;
    sourceRadix      = argv[1];
    destinationRadix = argv[2];
    inputValue       = argv[3];
    return true;
}

string RadixCalculation(string& sourceRadixStr, string& destinationRadixStr, string& inputValueStr, bool& wasError)
{
    int sourceRadix = StringToInt(sourceRadixStr, 10, wasError);
    if (wasError || sourceRadix < 2 || sourceRadix > 36)
    {
        wasError = true;
        return "Error: invalid source radix.";
    }

    int destinationRadix = StringToInt(destinationRadixStr, 10, wasError);
    if (wasError || destinationRadix < 2 || destinationRadix > 36)
    {
        wasError = true;
        return "Error: invalid destination radix.";
    }

    int value = StringToInt(inputValueStr, sourceRadix, wasError);
    if (wasError)
    {
        return "Error: invalid input value.";
    }

    string result = IntToString(value, destinationRadix, wasError);
    return result;
}
                                                                //done парсинг параметров входной строки отдельной функцией
                                                                //done main сложна
int main(int argc, char* argv[])
{
    bool wasError = false;
    string sourceRadixStr, destinationRadixStr, inputValueStr;

    if (!ParseArgs(argv, argc, sourceRadixStr, destinationRadixStr, inputValueStr))
    {
        cout << "Error: invalid number of arguments." << endl;
        return 1;
    }

    cout << RadixCalculation(sourceRadixStr, destinationRadixStr, inputValueStr, wasError) << endl;
    return wasError;
}
